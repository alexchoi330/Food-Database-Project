Additional Comments that we want to add that's not on the PDF:
to access our project, download and move these files into your public_html folder after logging onto the ubc server.
chmod 755 the files for permission and use https://www.students.cs.ubc.ca/~YOURCWL/project.php to access the page

or use this link https://www.students.cs.ubc.ca/~alexc330/project.php


